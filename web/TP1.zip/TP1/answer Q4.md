Les balises inline les plus courantes sont :
- `<strong>` pour mettre du texte en **gras**
- `<em>` pour mettre du texte en *italique*
- `<code>` pour mettre du texte en *code*
- `<a href="...">` pour mettre un lien vers une autre page
- `<pre>` pour mettre du code source
- `<blockquote>` pour mettre du texte en citation
- `<tr>` pour mettre du texte dans une ligne de tableau

Les balises block sont :
- `<p>` pour mettre du texte en paragraphe
- `<h1>` à `<h6>` pour mettre du texte en titre
- `<ul>` pour mettre du texte en liste non ordonnée
- `<ol>` pour mettre du texte en liste ordonnée
- `<li>` pour mettre du texte dans une liste
- `<table>` pour mettre un tableau
- `<img>` pour mettre une image

